site_name
---------

Set the given variable to the name of the computer.

.. code-block:: cmake

  site_name(variable)
