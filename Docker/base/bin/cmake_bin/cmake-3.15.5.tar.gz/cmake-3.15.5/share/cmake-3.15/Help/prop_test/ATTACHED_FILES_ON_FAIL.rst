ATTACHED_FILES_ON_FAIL
----------------------

Attach a list of files to a dashboard submission if the test fails.

Same as :prop_test:`ATTACHED_FILES`, but these files will only be
included if the test does not pass.
