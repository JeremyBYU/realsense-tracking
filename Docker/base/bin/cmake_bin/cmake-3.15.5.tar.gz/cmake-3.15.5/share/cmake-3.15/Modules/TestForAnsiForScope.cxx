int main(int, char* [])
{
  int i;
  for (int i = 0; i < 1; ++i)
    ;
  (void)i;
  return 0;
}
