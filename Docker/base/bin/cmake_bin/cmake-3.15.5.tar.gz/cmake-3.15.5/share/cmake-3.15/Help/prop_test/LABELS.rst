LABELS
------

Specify a list of text labels associated with a test.

The list is reported in dashboard submissions.
